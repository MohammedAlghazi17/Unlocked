# Unlocked
This project tends to address the issue of isolations and boredom as witnessed in the recent covid19 lockdown.  
The application called "LOCKDOWN" is a web based site where users are able to interact with their 
immediate surroundng as regards to rules and guidelines implemented in a national emergency.
It provides an easy user interation with our implementation of a BOT.
Furthermore, as a grpoup project, we implemented the use og google earth as map for geopositioning.
Also, we employed the use of both google and facebook API for registration and login.
